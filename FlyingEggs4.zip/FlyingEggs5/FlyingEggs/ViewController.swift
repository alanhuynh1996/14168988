//
//  LevelViewController.swift
//  FlyingEggs
//
//  Created by ah17acx on 09/01/2020.
//  Copyright © 2020 ah17acx. All rights reserved.
//

import UIKit
import AVFoundation


protocol subviewDelegate {
    func generateBall()
    func updateBallAngle(currentLocation: CGPoint)
}


class ViewController: UIViewController, subviewDelegate {
    
    var countdown = 20
    var timer = Timer()
    var score = 0
    
    var backbeats: AVAudioPlayer?
    
    var dynamicAnimator:                UIDynamicAnimator!
    var dynamicItemBehavior:            UIDynamicItemBehavior!
    var collisionBehavior:              UICollisionBehavior!
    var birdCollisionBehaviour:         UICollisionBehavior!
    var ballImageArray: [UIImageView]   = []
    var birdViewArray: [UIImageView]    = []
    
    let W = UIScreen.main.bounds.width
    let H = UIScreen.main.bounds.height
    
    var vectorX: CGFloat? = 0
    var vectorY: CGFloat? = 0

    let birdImageArray = [UIImage(named: "bird1.png")!,
                          UIImage(named: "bird2.png")!,
                          UIImage(named: "bird3.png")!,
                          UIImage(named: "bird4.png")!,
                          UIImage(named: "bird5.png")!,
                          
    ]
    
    
    func updateBallAngle(currentLocation: CGPoint){
        vectorX = currentLocation.x
        vectorY = currentLocation.y
    }
    
    
    func generateBall() {
        
        let ballImage = UIImageView(image: nil)
        
        ballImage.image = UIImage(named: "egg")
        
        ballImage.frame = CGRect(x: W*0.08, y: H*0.47, width: W*0.10, height: H*0.17)
        
        self.view.addSubview(ballImage)
        
        let angleX = vectorX! - self.Aim.bounds.midX
        let angleY = vectorY! - H*0.5
        
        ballImageArray.append(ballImage)
        
        dynamicItemBehavior.addItem(ballImage)
        
        dynamicItemBehavior.addLinearVelocity(CGPoint(x: angleX*5, y: angleY*5), for: ballImage)
        
        collisionBehavior.addItem(ballImage)
        
        let disappear = DispatchTime.now() + 2
        
        DispatchQueue.main.asyncAfter(deadline: disappear){
        ballImage.removeFromSuperview()
            
        }
        
    }
    
    func playBackBeatz() {
        guard let url = Bundle.main.url(forResource: "backMusic", withExtension: "mp3") else { return }

        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
            backbeats = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)

            guard let backbeats = backbeats else { return }

            backbeats.play()

        } catch let error {
            print(error.localizedDescription)
        }
    }
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
 
        startUp()
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(ViewController.counter), userInfo: nil, repeats: true )
        
        self.Aim.center.x = self.W * 0.10
        self.Aim.center.y = self.H * 0.50
        
        Aim.myDelegate = self
        
        dynamicAnimator = UIDynamicAnimator(referenceView: self.view)
        dynamicItemBehavior = UIDynamicItemBehavior(items: ballImageArray)
        dynamicAnimator.addBehavior(dynamicItemBehavior)
        dynamicAnimator.addBehavior(birdCollisionBehaviour)
        
        collisionBehavior = UICollisionBehavior(items: [])
        
        
        collisionBehavior = UICollisionBehavior(items: ballImageArray)
        //collisionBehavior.translatesReferenceBoundsIntoBoundary = true
        
        collisionBehavior.addBoundary(withIdentifier: "LEFTBOUNDARY" as NSCopying, from: CGPoint(x: self.W*0.0, y: self.H*0.0), to: CGPoint(x: self.W*0.0, y: self.H*1.0))
        
        collisionBehavior.addBoundary(withIdentifier: "TOPBOUNDARY" as NSCopying, from: CGPoint(x: self.W*0.0, y: self.H*0.0), to: CGPoint(x: self.W*1.0, y: self.H*0.0))
       
        collisionBehavior.addBoundary(withIdentifier: "BOTTOMBOUNDARY" as NSCopying, from: CGPoint(x: self.W*0.0, y: self.H*1.0), to: CGPoint(x: self.W*1.0, y: self.H*1.0))
        
        dynamicAnimator.addBehavior(collisionBehavior)
        
       
        }
         
    override func didReceiveMemoryWarning() {
                   super.didReceiveMemoryWarning()
    }

    
    func createBirdImage(){
        let number = 5
               let birdSize = Int(self.H)/number-2
                   

                       for index in 0...1000{
                           
                           let when = DispatchTime.now() + (Double(index)/2)
                             
                            DispatchQueue.main.asyncAfter(deadline: when) {
                               
                               while true {
                                   
                                   let randomHeight = Int(self.H)/number * Int.random(in: 0...number)
                                   
                                   let birdView = UIImageView(image: nil)
                                   
                                   birdView.image = self.birdImageArray.randomElement()
                                   
                                   birdView.frame = CGRect(x: self.W-CGFloat(birdSize), y:  CGFloat(randomHeight), width: CGFloat(birdSize),
                                   height: CGFloat(birdSize))
                                   
                                   self.view.addSubview(birdView)
                                   self.view.bringSubviewToFront(birdView)
                                   
                                   for anyBirdView in self.birdViewArray {
                                       if
                                           birdView.frame.intersects(anyBirdView.frame) {
                                           
                                           birdView.removeFromSuperview()
                                           
                                           continue
                                       }
               
                                   
                               }
                                   
                                   self.birdViewArray.append(birdView)
                                   break;
                       }
                       
                       
                       
                   }
                           
            }
    }

        
    func startUp(){
        
        playBackBeatz()
            
            self.createBirdImage()
            
            dynamicAnimator = UIDynamicAnimator(referenceView: self.view)
            
            Aim.frame = CGRect(x:W*0.02, y: H*0.4, width: W*0.2, height: H*0.2)
            Aim.myDelegate = self
            
            birdCollisionBehaviour = UICollisionBehavior(items: birdViewArray)
            
            self.birdCollisionBehaviour.action = {
                for ballView in self.ballImageArray{
                    for birdView in self.birdViewArray{
                        let index = self.birdViewArray.firstIndex(of: birdView)
                        if ballView.frame.intersects(birdView.frame)
                        
                        {
                            
                            birdView.removeFromSuperview()
                            self.birdViewArray.remove(at: index!)
                            self.score += 1
                            self.points.text = NSString(format: "Score: %i", self.score) as String
                            
                        }
                    }
                }
                
            }
            
            dynamicAnimator.addBehavior(birdCollisionBehaviour)
            
            
    }
     
    @objc func counter(){
        countdown -= 1
        timelimit.text = String(countdown)
        
        if(countdown == 0){
            timer.invalidate()
            timeUp()
            backbeats?.stop()

        }
    }
    
    func timeUp(){
        performSegue(withIdentifier: "getScore", sender: self)
        let game = UIStoryboard(name: "Main", bundle: nil)
        let restart = game.instantiateViewController(identifier: "replays")
        self.present(restart, animated: true, completion: nil)
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        let scoreChicken = segue.destination as! ReplaysViewController
        scoreChicken.scoregot = self.points.text!
    }
        
    

    @IBOutlet weak var points: UILabel!
    
    @IBOutlet weak var timelimit: UILabel!
    
    
    @IBOutlet weak var Aim: DragImageView!
    
}

