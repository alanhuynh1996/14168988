//
//  ReplayTwoViewController.swift
//  FlyingEggs
//
//  Created by Alan Huynh on 13/01/2020.
//  Copyright © 2020 ah17acx. All rights reserved.
//

import UIKit

class ReplaysTwoViewController: UIViewController {
    
    var scoregot = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        scorepoint.text = scoregot

    }
    

    @IBAction func replayB(_ sender: Any) {
        let game = UIStoryboard(name: "Main", bundle: nil)
        let restart = game.instantiateViewController(identifier: "gameScreen")
        self.present(restart, animated: true, completion: nil)
    }
    

    @IBAction func launchB(_ sender: Any) {
        let game = UIStoryboard(name: "Main", bundle: nil)
        let restart = game.instantiateViewController(identifier: "fpage")
        self.present(restart, animated: true, completion: nil)
    }
    
    
    @IBOutlet weak var scorepoint: UILabel!
}
