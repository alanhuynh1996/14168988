//
//  gameOverViewController.swift
//  FlyingEggs
//
//  Created by Alan Huynh on 12/01/2020.
//  Copyright © 2020 ah17acx. All rights reserved.
//

import UIKit

class gameOverViewController: UIViewController {

    var scoregot = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        scorepoint.text = scoregot

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBOutlet weak var scorepoint: UILabel!
    @IBAction func replay(_ sender: Any) {
        let game = UIStoryboard(name: "Main", bundle: nil)
        let restart = game.instantiateViewController(identifier: "gameScreen")
        self.present(restart, animated: true, completion: nil)
        
    }
    
    
}
