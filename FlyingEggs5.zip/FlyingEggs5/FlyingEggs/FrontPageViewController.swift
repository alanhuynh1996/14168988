//
//  FrontPageViewController.swift
//  FlyingEggs
//
//  Created by ah17acx on 11/01/2020.
//  Copyright © 2020 ah17acx. All rights reserved.
//

import UIKit
import AVFoundation

class FrontPageViewController: UIViewController {
    

    @IBOutlet weak var imageDuck: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        

        var imageArray: [UIImage]!
         imageArray = [UIImage(named:"f1.gif")!,
                       UIImage(named:"f2.gif")!,
                       UIImage(named:"f3.gif")!,
                       UIImage(named:"f4.gif")!,
                       UIImage(named:"f5.gif")!,
                       UIImage(named:"f6.gif")!,
                       UIImage(named:"f7.gif")!,
                       UIImage(named:"f8.gif")!,
                       UIImage(named:"f9.gif")!,
                       UIImage(named:"f10.gif")!,
                       UIImage(named:"f11.gif")!,
                       UIImage(named:"f12.gif")!,
                       UIImage(named:"f13.gif")!,
                       UIImage(named:"f14.gif")!,
                       UIImage(named:"f15.gif")!,
                       UIImage(named:"f16.gif")!,
                       UIImage(named:"f17.gif")!,
                       UIImage(named:"f18.gif")!,
                       UIImage(named:"f19.gif")!,
                       UIImage(named:"f20.gif")!,
                       UIImage(named:"f21.gif")!,
                       UIImage(named:"f22.gif")!,
                       UIImage(named:"f23.gif")!,
                       UIImage(named:"f24.gif")!,
                       UIImage(named:"f25.gif")!]
        
        imageDuck.image = UIImage.animatedImage(with: imageArray, duration: 1)
   
        
         
    }
    

}
