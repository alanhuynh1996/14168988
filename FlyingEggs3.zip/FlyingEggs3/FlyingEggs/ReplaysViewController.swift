//
//  ReplaysViewController.swift
//  FlyingEggs
//
//  Created by ah17acx on 11/01/2020.
//  Copyright © 2020 ah17acx. All rights reserved.
//

import UIKit

class ReplaysViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    

    @IBAction func replayB(_ sender: Any) {
        let game = UIStoryboard(name: "Main", bundle: nil)
        let restart = game.instantiateViewController(identifier: "gameScreen")
        self.present(restart, animated: true, completion: nil)
    }
    

    @IBAction func launchB(_ sender: Any) {
        let game = UIStoryboard(name: "Main", bundle: nil)
        let restart = game.instantiateViewController(identifier: "fpage")
        self.present(restart, animated: true, completion: nil)
    }
}
